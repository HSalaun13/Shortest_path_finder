def feets(feet):
    if feet <0 : 
        return error 
    else:
       return feet * 30.48

def inch(inches):
    if inches <0 : 
        return error 
    else:
       return inches * 2.54

def yard(yards):
    if yards <0 : 
        return error 
    else:
       return yards * 91.44


opcion = int(input())     
if(opcion == 1):
    feet  = float(input())
    print(feets(feet))
elif(opcion == 2):
    inches  = int(input())
    print(inch(inches))
elif(opcion == 3):
    yards  = int(input())
    print(yard(yards))
else :
    print('Error')
if feets(feet) < 0 or inch(inches) < 0 or yard(yards) < 0:
    print('Error')
     